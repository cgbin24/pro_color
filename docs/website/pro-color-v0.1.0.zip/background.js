import { a as getSiteTheme, b as saveSiteTheme, g as getConfig, s as saveConfig, c as saveButtonPosition } from "./storage.js";
const createContextMenu = () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "pro-color-options",
      title: "管理扩展程序",
      contexts: ["action"]
    });
    chrome.contextMenus.create({
      id: "pro-color-toggle-button",
      title: "显示/隐藏悬浮按钮",
      contexts: ["action"]
    });
  });
};
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "pro-color-options") {
    chrome.runtime.openOptionsPage();
  } else if (info.menuItemId === "pro-color-toggle-button" && (tab == null ? void 0 : tab.id)) {
    chrome.tabs.sendMessage(tab.id, {
      action: "toggleFloatingButton"
    }).catch((error) => {
      console.log("Content script not ready yet");
    });
  }
});
chrome.runtime.onInstalled.addListener((details) => {
  createContextMenu();
  if (details.reason === "install") {
    chrome.tabs.create({ url: "options.html" });
  }
});
chrome.action.onClicked.addListener((tab) => {
  if (tab.id) {
    chrome.tabs.sendMessage(tab.id, {
      action: "toggleFloatingButton"
    }).catch((error) => {
      console.log("Content script not ready yet, opening options page instead");
      chrome.runtime.openOptionsPage();
    });
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getSiteTheme" && message.hostname) {
    getSiteTheme(message.hostname).then((theme) => {
      sendResponse({ theme });
    }).catch((error) => {
      console.error("Error getting site theme:", error);
      sendResponse({ error: error.message });
    });
    return true;
  }
  if (message.action === "saveTheme" && message.hostname && message.theme) {
    saveSiteTheme(message.hostname, message.theme).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Error saving site theme:", error);
      sendResponse({ error: error.message });
    });
    return true;
  }
  if (message.action === "removeSiteTheme" && message.hostname) {
    getSiteTheme(message.hostname).then((theme) => {
      if (theme) {
        return getConfig().then((config) => {
          delete config.themes[message.hostname];
          return saveConfig(config);
        });
      }
    }).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Error removing site theme:", error);
      sendResponse({ error: error.message });
    });
    return true;
  }
  if (message.action === "saveButtonPosition" && message.edge) {
    saveButtonPosition(message.edge, message.y).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Error saving button position:", error);
      sendResponse({ error: error.message });
    });
    return true;
  }
  if (message.action === "getButtonPosition") {
    getConfig().then((config) => {
      sendResponse({
        position: config.floatingButtonPosition || {
          edge: "right",
          y: 50
        }
      });
    }).catch((error) => {
      console.error("Error getting button position:", error);
      sendResponse({
        error: error.message,
        position: { edge: "right", y: 50 }
        // 提供默认值
      });
    });
    return true;
  }
  if (message.action === "openOptionsPage") {
    chrome.runtime.openOptionsPage();
    sendResponse({ success: true });
    return true;
  }
  return false;
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.url.startsWith("http")) {
    const url = new URL(tab.url);
    getSiteTheme(url.hostname).then((theme) => {
      if (theme) {
        chrome.tabs.sendMessage(tabId, {
          action: "applyTheme",
          theme
        }).catch((error) => {
          console.log("Content script not ready yet");
        });
      }
    }).catch((error) => {
      console.error("Error getting site theme on tab update:", error);
    });
  }
});
