(function() {
  "use strict";
  const DEFAULT_THEMES = [
    { id: "theme-white", name: "白色主题", colorClass: "theme-white-color" },
    { id: "theme-green", name: "护眼绿色", colorClass: "theme-green-color" },
    { id: "theme-yellow", name: "黄色类纸", colorClass: "theme-yellow-color" },
    { id: "theme-night", name: "夜间深色", colorClass: "theme-night-color" }
  ];
  const BUTTON_HTML = `
<button id="pro-color-floating-button" title="Pro Color 主题切换">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="#3F3F46" stroke-width="2"/>
    <path d="M7 12.5C7.82843 12.5 8.5 11.8284 8.5 11C8.5 10.1716 7.82843 9.5 7 9.5C6.17157 9.5 5.5 10.1716 5.5 11C5.5 11.8284 6.17157 12.5 7 12.5Z" fill="#3F3F46"/>
    <path d="M12 16.5C12.8284 16.5 13.5 15.8284 13.5 15C13.5 14.1716 12.8284 13.5 12 13.5C11.1716 13.5 10.5 14.1716 10.5 15C10.5 15.8284 11.1716 16.5 12 16.5Z" fill="#3F3F46"/>
    <path d="M17 12.5C17.8284 12.5 18.5 11.8284 18.5 11C18.5 10.1716 17.8284 9.5 17 9.5C16.1716 9.5 15.5 10.1716 15.5 11C15.5 11.8284 16.1716 12.5 17 12.5Z" fill="#3F3F46"/>
  </svg>
</button>
<div id="pro-color-theme-panel">
  ${DEFAULT_THEMES.map((theme) => `
    <div class="pro-color-theme-option" data-theme="${theme.id}">
      <div class="pro-color-theme-color ${theme.colorClass}"></div>
      <div class="pro-color-theme-name">${theme.name}</div>
    </div>
  `).join("")}
  <div class="pro-color-theme-option pro-color-reset" data-theme="reset">
    <div class="pro-color-theme-color theme-reset-color">
      <svg t="1747197066551" class="icon" viewBox="0 0 1027 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="15718" width="200" height="200"><path d="M1020.44444 460.8l-185.6-230.4c-19.2-25.6-57.6-25.6-76.8 0l-185.6 230.4c-12.8 19.2 0 44.8 19.2 44.8h70.4c0 134.4 0 307.2-243.2 448-6.4 6.4 0 12.8 6.4 12.8 454.4-70.4 492.8-377.6 492.8-460.8h76.8c25.6 0 38.4-25.6 25.6-44.8z m-582.4 57.6h-76.8c0-134.4 0-307.2 243.2-448 6.4-6.4 0-12.8-6.4-12.8-454.4 70.4-492.8 377.6-492.8 460.8h-76.8c-25.6 0-38.4 25.6-19.2 44.8l185.6 230.4c19.2 25.6 57.6 25.6 76.8 0l185.6-230.4c12.8-19.2 0-44.8-19.2-44.8z" fill="#cdcdcd" p-id="15719"></path></svg>
    </div>
    <div class="pro-color-theme-name">重置主题</div>
  </div>
</div>
`;
  const FLOATING_BUTTON_CONFIG = {
    DRAG_THRESHOLD: 5,
    // 拖动阈值，小于此值被视为点击
    CLICK_TIME_THRESHOLD: 200,
    // 毫秒，小于此值被视为点击
    EDGE_GAP: 20,
    // 按钮距离屏幕边缘距离（吸附时）
    BUTTON_SIZE: 44,
    // 按钮尺寸
    PANEL_BUTTON_GAP: 15
  };
  const markBackgroundImages = () => {
    console.log("开始检测背景图片元素");
    const potentialBgElements = document.querySelectorAll(
      '[style*="background"],[style*="url("],[data-bg],[data-background],[data-background-image],[data-src],[class*="bg-"],[class*="background"],[class*="banner"],[class*="cover"],[class*="header"],[class*="hero"],[class*="slider"],[class*="carousel"],[class*="image"],[class*="img"],[class*="logo"],[class*="icon"],[class*="thumbnail"],[class*="avatar"],[id*="bg-"],[id*="background"],[id*="banner"],[id*="image"],[id*="logo"],.bg,.background,.banner,.image,.img,.logo,.icon,.cover,.header,.hero,.slider,.carousel,.avatar,.thumbnail'
    );
    console.log(`找到 ${potentialBgElements.length} 个可能有背景图的元素`);
    potentialBgElements.forEach((element) => {
      if (element instanceof HTMLElement) {
        try {
          element.classList.add("has-bg-image");
          checkPseudoElementBackground(element);
        } catch (error) {
        }
      }
    });
    const allElements = document.querySelectorAll("*");
    console.log(`检查所有 ${allElements.length} 个元素的计算样式`);
    const BATCH_SIZE = 500;
    processBatch(0, allElements, BATCH_SIZE);
  };
  const processBatch = (startIndex, allElements, BATCH_SIZE) => {
    const endIndex = Math.min(startIndex + BATCH_SIZE, allElements.length);
    for (let i = startIndex; i < endIndex; i++) {
      const element = allElements[i];
      if (element instanceof HTMLElement && !element.classList.contains("has-bg-image")) {
        try {
          const style = window.getComputedStyle(element);
          const bgImage = style.backgroundImage;
          if (bgImage && bgImage !== "none" && !bgImage.includes("linear-gradient") && bgImage.includes("url(")) {
            element.classList.add("has-bg-image");
            continue;
          }
          const styleAttr = element.getAttribute("style");
          if (styleAttr && (styleAttr.includes("background-image") || styleAttr.includes("background:") || styleAttr.includes("background-image:") || styleAttr.includes("url("))) {
            element.classList.add("has-bg-image");
            continue;
          }
          const className = element.className;
          const id = element.id;
          if (className && (className.includes("bg-") || className.includes("background") || className.includes("image") || className.includes("banner") || className.includes("logo") || className.includes("header") || className.includes("cover")) || id && (id.includes("bg-") || id.includes("background") || id.includes("image") || id.includes("banner") || id.includes("logo"))) {
            element.classList.add("has-bg-image");
            continue;
          }
          checkPseudoElementBackground(element);
        } catch (error) {
        }
      }
    }
    if (endIndex < allElements.length) {
      setTimeout(() => processBatch(endIndex, allElements, BATCH_SIZE), 0);
    } else {
      console.log("背景图片检测完成");
    }
  };
  const checkPseudoElementBackground = (element) => {
    try {
      const beforeStyle = window.getComputedStyle(element, ":before");
      const beforeBg = beforeStyle.backgroundImage;
      if (beforeBg && beforeBg !== "none" && !beforeBg.includes("linear-gradient") && beforeBg.includes("url(")) {
        element.classList.add("has-bg-image");
        element.setAttribute("data-has-pseudo-bg", "true");
        return;
      }
      const afterStyle = window.getComputedStyle(element, ":after");
      const afterBg = afterStyle.backgroundImage;
      if (afterBg && afterBg !== "none" && !afterBg.includes("linear-gradient") && afterBg.includes("url(")) {
        element.classList.add("has-bg-image");
        element.setAttribute("data-has-pseudo-bg", "true");
        return;
      }
    } catch (error) {
    }
  };
  const protectUIElements = () => {
    const uiElements = document.querySelectorAll(
      '#pro-color-container, #pro-color-floating-button, #pro-color-theme-panel, .pro-color-theme-option, .pro-color-theme-color, .pro-color-theme-name, [id^="pro-color"], [class^="pro-color"]'
    );
    uiElements.forEach((element) => {
      if (element instanceof HTMLElement) {
        element.classList.add("pro-color-ui");
      }
    });
  };
  const protection = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    protectUIElements
  }, Symbol.toStringTag, { value: "Module" }));
  const addSiteIdentification = (hostname) => {
    const html = document.documentElement;
    let siteType = "";
    if (hostname.includes("baidu.com")) {
      siteType = "baidu";
    } else if (hostname.includes("bing.com")) {
      siteType = "bing";
    } else if (hostname.includes("google.com")) {
      siteType = "google";
    } else if (hostname.includes("github.com")) {
      siteType = "github";
    } else if (hostname.includes("youtube.com")) {
      siteType = "youtube";
    }
    if (siteType) {
      html.setAttribute("data-site", siteType);
    } else {
      html.removeAttribute("data-site");
    }
  };
  const processSpecificElements = (themeName) => {
    const hostname = window.location.hostname;
    addSiteIdentification(hostname);
    if (hostname.includes("baidu.com")) {
      processBaiduElements();
    }
  };
  const processBaiduElements = (themeName) => {
    const searchBox = document.querySelector(".s_form");
    if (searchBox && searchBox instanceof HTMLElement) {
      searchBox.classList.add("pro-color-preserved");
    }
    const resultArea = document.getElementById("content_left");
    if (resultArea) {
      const images = resultArea.querySelectorAll("img");
      images.forEach((img) => {
        img.classList.add("pro-color-preserved");
        const parent = img.parentElement;
        if (parent) {
          parent.classList.add("pro-color-preserved");
        }
      });
      const titleLinks = resultArea.querySelectorAll(".c-title a");
      titleLinks.forEach((link) => {
        if (link instanceof HTMLElement) {
          link.style.setProperty("color", "#2440b3", "important");
          link.classList.add("pro-color-preserved");
        }
      });
    }
    const navs = document.querySelectorAll(".s-top-nav-tab-item");
    navs.forEach((nav) => {
      if (nav instanceof HTMLElement) {
        nav.style.backgroundColor = "transparent";
        nav.classList.add("pro-color-preserved");
      }
    });
  };
  let globalObserver = null;
  const createDomObserver = () => {
    if (globalObserver) {
      globalObserver.disconnect();
      globalObserver = null;
    }
    const getCurrentTheme = () => {
      const html = document.documentElement;
      if (!html.classList.contains("pro-color-theme-applied")) {
        return null;
      }
      for (const theme of DEFAULT_THEMES) {
        if (html.classList.contains(theme.id)) {
          return theme.id;
        }
      }
      return null;
    };
    const shouldExcludeElement = (element) => {
      if (element.id && element.id.includes("pro-color")) return true;
      if (element.classList && [...element.classList].some((cls) => cls.includes("pro-color"))) return true;
      const tagName = element.tagName.toLowerCase();
      if (["img", "video", "canvas", "svg", "iframe", "embed", "object"].includes(tagName)) return true;
      if (element.getAttribute("role") === "img") return true;
      if (element.getAttribute("aria-hidden") === "true") return true;
      if (element instanceof HTMLElement) {
        const computedStyle = window.getComputedStyle(element);
        const bgImage = computedStyle.backgroundImage;
        if (bgImage && bgImage !== "none" && !bgImage.includes("linear-gradient")) {
          element.classList.add("has-bg-image");
          return true;
        }
      }
      if (element.className && (element.className.includes("logo") || element.className.includes("icon") || element.className.includes("avatar"))) return true;
      if (element.id && (element.id.includes("ad") || element.id.includes("banner") || element.id.includes("promotion"))) return true;
      if (element.className && (element.className.includes("ad") || element.className.includes("banner") || element.className.includes("promotion") || element.className.includes("sponsor"))) return true;
      if (element.classList.contains("pro-color-processed") || element.classList.contains("pro-color-preserved")) {
        return true;
      }
      if (window.location.hostname.includes("baidu.com")) {
        if (element.id === "s_form" || element.id === "result" || element.id === "content_right" || // 右侧广告区域
        element.className.includes("s_ipt_wr") || element.className.includes("s_btn_wr") || element.className.includes("s-top-nav")) {
          return true;
        }
        if (tagName === "img" || element.querySelector("img")) return true;
        if (element.className && (element.className.includes("btn") || element.className.includes("tool") || element.className.includes("tabs") || element.className.includes("c-title"))) {
          return true;
        }
      }
      if (element.id && typeof element.id.includes === "function" && element.id.includes("pro-color")) return true;
      if (element.classList && (element.classList.contains("pro-color-ui") || element.classList.contains("pro-color-protected"))) return true;
      return false;
    };
    const applyThemeToElement = (element, themeName) => {
      if (shouldExcludeElement(element)) return;
      try {
        element.classList.add("pro-color-processed");
        if (element instanceof HTMLElement) {
          const computedStyle = window.getComputedStyle(element);
          if (computedStyle.backgroundImage && computedStyle.backgroundImage !== "none" && !computedStyle.backgroundImage.includes("linear-gradient")) {
            element.classList.add("has-bg-image");
            return;
          }
          if (element.id && element.id.includes("pro-color")) return;
          if (element.className && element.className.includes("pro-color")) return;
          if (window.getComputedStyle(element).backgroundColor !== "rgba(0, 0, 0, 0)" && !element.style.backgroundColor.includes("var(--bg-color)")) {
            element.style.setProperty("background-color", "var(--bg-color)", "important");
          }
          if (window.getComputedStyle(element).color !== "rgba(0, 0, 0, 0)" && !element.style.color.includes("var(--text-color)")) {
            element.style.setProperty("color", "var(--text-color)", "important");
          }
          if (window.getComputedStyle(element).borderColor !== "rgba(0, 0, 0, 0)" && !element.style.borderColor.includes("var(--border-color)")) {
            element.style.setProperty("border-color", "var(--border-color)", "important");
          }
          if (element.tagName.toLowerCase() === "a" && !element.style.color.includes("var(--link-color)")) {
            element.style.setProperty("color", "var(--link-color)", "important");
          }
        }
      } catch (error) {
        console.debug("Pro Color: 元素样式应用错误", error);
      }
    };
    const observer = new MutationObserver((mutations) => {
      const currentTheme = getCurrentTheme();
      if (!currentTheme) return;
      mutations.forEach((mutation) => {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          const newElements = /* @__PURE__ */ new Set();
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              const element = node;
              newElements.add(element);
              element.querySelectorAll("*").forEach((child) => {
                newElements.add(child);
              });
            }
          });
          const bgCandidates = Array.from(newElements).filter((el) => {
            if (!(el instanceof HTMLElement)) return false;
            const tagName = el.tagName.toLowerCase();
            if (["img", "video", "canvas", "svg", "iframe"].includes(tagName)) {
              return false;
            }
            const styleAttr = el.getAttribute("style");
            if (styleAttr && (styleAttr.includes("background") || styleAttr.includes("url("))) {
              return true;
            }
            const className = el.className;
            const id = el.id;
            if (className && (className.includes("bg-") || className.includes("background") || className.includes("image") || className.includes("banner") || className.includes("cover") || className.includes("header") || className.includes("logo") || className.includes("icon") || className.includes("carousel") || className.includes("slider") || className.includes("thumbnail") || className.includes("avatar")) || id && (id.includes("bg-") || id.includes("background") || id.includes("image") || id.includes("banner") || id.includes("logo") || id.includes("icon"))) {
              return true;
            }
            if (el.hasAttribute("data-bg") || el.hasAttribute("data-background") || el.hasAttribute("data-background-image") || el.hasAttribute("data-src")) {
              return true;
            }
            return false;
          });
          bgCandidates.forEach((element) => {
            if (element instanceof HTMLElement) {
              element.classList.add("has-bg-image");
              try {
                const beforeStyle = window.getComputedStyle(element, ":before");
                if (beforeStyle.backgroundImage && beforeStyle.backgroundImage !== "none" && beforeStyle.backgroundImage.includes("url(")) {
                  element.setAttribute("data-has-pseudo-bg", "true");
                }
                const afterStyle = window.getComputedStyle(element, ":after");
                if (afterStyle.backgroundImage && afterStyle.backgroundImage !== "none" && afterStyle.backgroundImage.includes("url(")) {
                  element.setAttribute("data-has-pseudo-bg", "true");
                }
              } catch (e) {
              }
            }
          });
          newElements.forEach((element) => {
            var _a, _b;
            if (element.classList.contains("has-bg-image")) return;
            if (((_a = element.classList) == null ? void 0 : _a.contains("pro-color-ui")) || ((_b = element.classList) == null ? void 0 : _b.contains("pro-color-protected"))) {
              return;
            }
            if (shouldExcludeElement(element)) return;
            if (!element.classList.contains("pro-color-processed")) {
              applyThemeToElement(element);
            }
          });
        }
      });
      Promise.resolve().then(() => protection).then(({ protectUIElements: protectUIElements2 }) => {
        protectUIElements2();
      });
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: false
      // 不观察属性变化，减少不必要的触发
    });
    globalObserver = observer;
    return observer;
  };
  const disconnectDomObserver = () => {
    if (globalObserver) {
      globalObserver.disconnect();
      globalObserver = null;
      console.log("DOM观察器已断开");
    }
  };
  const applyTheme = (themeName) => {
    console.log("应用主题:", themeName);
    const html = document.documentElement;
    if (!themeName) {
      disconnectDomObserver();
      document.querySelectorAll(".has-bg-image").forEach((el) => {
        el.classList.remove("has-bg-image");
        el.removeAttribute("data-has-pseudo-bg");
      });
      DEFAULT_THEMES.forEach((theme) => {
        html.classList.remove(theme.id);
      });
      html.classList.remove("pro-color-theme-applied");
      html.removeAttribute("data-site");
      document.querySelectorAll(".pro-color-processed").forEach((el) => {
        if (el instanceof HTMLElement) {
          el.style.removeProperty("background-color");
          el.style.removeProperty("color");
          el.style.removeProperty("border-color");
          el.classList.remove("pro-color-processed");
        }
      });
    } else {
      markBackgroundImages();
      DEFAULT_THEMES.forEach((theme) => {
        html.classList.remove(theme.id);
      });
      html.classList.add(themeName);
      html.classList.add("pro-color-theme-applied");
      document.querySelectorAll(".pro-color-processed").forEach((el) => {
        el.classList.remove("pro-color-processed");
      });
      processSpecificElements();
      createDomObserver();
    }
    protectUIElements();
  };
  const initThemeHandler = async () => {
    chrome.runtime.sendMessage(
      { action: "getSiteTheme", hostname: window.location.hostname },
      (response) => {
        if (response && response.theme) {
          applyTheme(response.theme);
        } else {
          applyTheme(null);
        }
      }
    );
  };
  let button;
  let panel;
  const FloatingButtonController = {
    // 状态变量
    state: {
      isDragging: false,
      isPanelVisible: false,
      isButtonOnRight: false,
      // 标记按钮是否在右侧
      dragStartTime: 0,
      initialMouseX: 0,
      initialMouseY: 0,
      initialButtonX: 0,
      initialButtonY: 0,
      buttonRect: null,
      dragDistance: 0,
      animationFrameId: null,
      currentPosition: {
        x: window.innerWidth - FLOATING_BUTTON_CONFIG.EDGE_GAP - 22,
        // 默认右侧位置
        y: window.innerHeight / 2
      }
    },
    // 初始化
    init() {
      button = document.getElementById("pro-color-floating-button");
      panel = document.getElementById("pro-color-theme-panel");
      this.setButtonPosition(window.innerWidth - FLOATING_BUTTON_CONFIG.EDGE_GAP - 22, window.innerHeight / 2);
      this.state.isButtonOnRight = true;
      button.addEventListener("mousedown", this.handleMouseDown.bind(this));
      button.addEventListener("click", this.handleClick.bind(this));
      button.addEventListener("contextmenu", this.handleContextMenu.bind(this));
      this.initThemeOptions();
      document.addEventListener("click", this.handleOutsideClick.bind(this));
      window.addEventListener("resize", this.handleWindowResize.bind(this));
      this.initButtonPosition();
      console.log("Pro Color floating button initialized");
    },
    // 初始化按钮位置
    initButtonPosition() {
      chrome.runtime.sendMessage(
        { action: "getButtonPosition" },
        (response) => {
          if (response && response.position) {
            const { edge, y: yPercent } = response.position;
            const yPixel = window.innerHeight * yPercent / 100;
            let xPixel;
            if (edge === "left") {
              xPixel = FLOATING_BUTTON_CONFIG.EDGE_GAP + button.offsetWidth / 2;
              this.state.isButtonOnRight = false;
            } else {
              xPixel = window.innerWidth - FLOATING_BUTTON_CONFIG.EDGE_GAP - button.offsetWidth / 2;
              this.state.isButtonOnRight = true;
            }
            console.log("初始化按钮位置 (中心点):", { edge, yPercent, xPixel, yPixel });
            this.setButtonPosition(xPixel, yPixel, false, true);
          } else {
            const defaultX = window.innerWidth - FLOATING_BUTTON_CONFIG.EDGE_GAP - button.offsetWidth / 2;
            const defaultY = window.innerHeight / 2;
            this.state.isButtonOnRight = true;
            this.setButtonPosition(defaultX, defaultY, false, true);
          }
        }
      );
    },
    // 窗口大小变化处理
    handleWindowResize() {
      const { x, y } = this.state.currentPosition;
      const newX = Math.min(Math.max(22, x), window.innerWidth - 44);
      const newY = Math.min(Math.max(22, y), window.innerHeight - 22);
      if (newX !== x || newY !== y) {
        this.setButtonPosition(newX, newY);
      }
    },
    // 设置按钮位置（使用绝对像素）
    setButtonPosition(x, y, isSnappingAnimation = false, initialSetup = false) {
      x = Math.max(button.offsetWidth / 2, Math.min(window.innerWidth - button.offsetWidth / 2, x));
      y = Math.max(button.offsetHeight / 2, Math.min(window.innerHeight - button.offsetHeight / 2, y));
      this.state.currentPosition = { x, y };
      if (x <= window.innerWidth / 2) {
        this.state.isButtonOnRight = false;
      } else {
        this.state.isButtonOnRight = true;
      }
      let transitionProperties = [];
      if (isSnappingAnimation) {
        transitionProperties.push("left 0.2s ease", "right 0.2s ease");
      } else if (!initialSetup && !this.state.isDragging) {
        transitionProperties.push("left 0.2s ease", "right 0.2s ease", "top 0.2s ease");
      }
      button.style.transition = transitionProperties.join(", ") || "none";
      if (this.state.isButtonOnRight) {
        button.style.right = `${window.innerWidth - x}px`;
        button.style.left = "auto";
        button.style.transform = "translate(50%, -50%)";
      } else {
        button.style.left = `${x}px`;
        button.style.right = "auto";
        button.style.transform = "translate(-50%, -50%)";
      }
      button.style.top = `${y}px`;
      if (initialSetup) {
        button.style.opacity = "1";
        button.style.pointerEvents = "auto";
        setTimeout(() => {
          if (button && !this.state.isDragging) {
            button.style.transition = "left 0.2s ease, right 0.2s ease, top 0.2s ease, opacity 0.2s ease";
          }
        }, 50);
      }
      if (isSnappingAnimation) {
        setTimeout(() => {
          if (button && !this.state.isDragging) {
            button.style.transition = "left 0.2s ease, right 0.2s ease, top 0.2s ease, opacity 0.2s ease";
          }
        }, 200);
      }
      if (!this.state.isDragging) {
        this.updatePanelPosition(this.state.isButtonOnRight);
      }
    },
    // 更新面板位置
    updatePanelPosition(isPanelOnLeft) {
      const { x, y } = this.state.currentPosition;
      const isActuallyOnRight = this.state.isButtonOnRight || x > window.innerWidth / 2;
      panel.removeAttribute("style");
      panel.style.position = "fixed";
      panel.style.top = `${y}px`;
      panel.style.transform = "translateY(-50%)";
      panel.style.transition = "all 0.25s ease-out";
      const offset = FLOATING_BUTTON_CONFIG.EDGE_GAP + FLOATING_BUTTON_CONFIG.BUTTON_SIZE + FLOATING_BUTTON_CONFIG.PANEL_BUTTON_GAP;
      if (isActuallyOnRight) {
        panel.style.right = `${offset}px`;
        panel.style.left = "auto";
      } else {
        panel.style.left = `${offset}px`;
        panel.style.right = "auto";
      }
      panel.classList.remove("panel-left", "panel-right");
      panel.classList.add(isActuallyOnRight ? "panel-left" : "panel-right");
      if (this.state.isPanelVisible) {
        panel.classList.add("visible");
      } else {
        panel.classList.remove("visible");
      }
    },
    // 处理鼠标按下事件
    handleMouseDown(e) {
      if (e.button !== 0) return;
      const rect = button.getBoundingClientRect();
      this.state.isDragging = false;
      this.state.buttonRect = rect;
      this.state.initialMouseX = e.clientX;
      this.state.initialMouseY = e.clientY;
      this.state.initialButtonX = this.state.currentPosition.x;
      this.state.initialButtonY = this.state.currentPosition.y;
      this.state.dragStartTime = Date.now();
      this.state.dragDistance = 0;
      document.addEventListener("mousemove", this.handleMouseMove);
      document.addEventListener("mouseup", this.handleMouseUp);
      e.preventDefault();
      e.stopPropagation();
    },
    // 处理鼠标移动事件（使用箭头函数避免this绑定问题）
    handleMouseMove: function(e) {
      const self = FloatingButtonController;
      const dx = e.clientX - self.state.initialMouseX;
      const dy = e.clientY - self.state.initialMouseY;
      self.state.dragDistance = Math.sqrt(dx * dx + dy * dy);
      if (self.state.dragDistance > FLOATING_BUTTON_CONFIG.DRAG_THRESHOLD) {
        if (!self.state.isDragging) {
          self.state.isDragging = true;
          button.classList.add("dragging");
          if (self.state.isPanelVisible) {
            self.state.isPanelVisible = false;
            panel.classList.remove("visible");
          }
          self.state.initialButtonX = self.state.currentPosition.x;
          self.state.initialButtonY = self.state.currentPosition.y;
          button.style.position = "fixed";
          button.style.left = self.state.initialButtonX + "px";
          button.style.top = self.state.initialButtonY + "px";
          button.style.right = "auto";
          button.style.transform = "translate(-50%, -50%)";
        }
        if (self.state.animationFrameId) {
          cancelAnimationFrame(self.state.animationFrameId);
        }
        self.state.animationFrameId = requestAnimationFrame(() => {
          button.style.transform = `translate(${dx}px, ${dy}px) translate(-50%, -50%)`;
          self.state.currentPosition.x = self.state.initialButtonX + dx;
          self.state.currentPosition.y = self.state.initialButtonY + dy;
        });
      }
    },
    // 处理鼠标松开事件
    handleMouseUp: function(e) {
      const self = FloatingButtonController;
      document.removeEventListener("mousemove", self.handleMouseMove);
      document.removeEventListener("mouseup", self.handleMouseUp);
      if (self.state.isDragging) {
        button.classList.remove("dragging");
        self.state.isDragging = false;
        let finalY = self.state.currentPosition.y;
        let currentXCenter = self.state.currentPosition.x;
        finalY = Math.max(button.offsetHeight / 2, Math.min(window.innerHeight - button.offsetHeight / 2, finalY));
        let finalXCenter;
        let intendedToBeOnRight;
        const determineSnapPosition = () => {
          {
            if (currentXCenter < window.innerWidth / 2) {
              finalXCenter = FLOATING_BUTTON_CONFIG.EDGE_GAP + button.offsetWidth / 2;
              intendedToBeOnRight = false;
            } else {
              finalXCenter = window.innerWidth - FLOATING_BUTTON_CONFIG.EDGE_GAP - button.offsetWidth / 2;
              intendedToBeOnRight = true;
            }
          }
        };
        determineSnapPosition();
        self.state.isButtonOnRight = intendedToBeOnRight;
        button.style.transform = "";
        self.setButtonPosition(finalXCenter, finalY, true, false);
        const edge = self.state.isButtonOnRight ? "right" : "left";
        const yPercent = Math.round(finalY / window.innerHeight * 100);
        chrome.runtime.sendMessage({
          action: "saveButtonPosition",
          edge,
          y: yPercent
        });
      }
      self.state.buttonRect = null;
      if (self.state.animationFrameId) {
        cancelAnimationFrame(self.state.animationFrameId);
        self.state.animationFrameId = null;
      }
      self.state.dragDistance = 0;
    },
    // 处理点击事件
    handleClick(e) {
      if (this.state.dragDistance < FLOATING_BUTTON_CONFIG.DRAG_THRESHOLD && Date.now() - this.state.dragStartTime < FLOATING_BUTTON_CONFIG.CLICK_TIME_THRESHOLD) {
        this.state.isPanelVisible = !this.state.isPanelVisible;
        const isPanelOnLeft = this.state.currentPosition.x > window.innerWidth / 2;
        this.updatePanelPosition(isPanelOnLeft);
      }
    },
    // 初始化主题选项
    initThemeOptions() {
      const themeOptions = document.querySelectorAll(".pro-color-theme-option");
      themeOptions.forEach((option) => {
        option.addEventListener("click", () => {
          const theme = option.getAttribute("data-theme");
          if (theme === "reset") {
            applyTheme(null);
            chrome.runtime.sendMessage({
              action: "removeSiteTheme",
              hostname: window.location.hostname
            });
          } else {
            applyTheme(theme);
            chrome.runtime.sendMessage({
              action: "saveTheme",
              hostname: window.location.hostname,
              theme
            });
          }
          this.state.isPanelVisible = false;
          const isPanelOnLeft = this.state.currentPosition.x > window.innerWidth / 2;
          this.updatePanelPosition(isPanelOnLeft);
        });
      });
    },
    // 处理外部点击
    handleOutsideClick(e) {
      if (this.state.isPanelVisible && !panel.contains(e.target) && !button.contains(e.target)) {
        this.state.isPanelVisible = false;
        const isPanelOnLeft = this.state.currentPosition.x > window.innerWidth / 2;
        this.updatePanelPosition(isPanelOnLeft);
      }
    },
    // 处理右键菜单
    handleContextMenu(e) {
      e.preventDefault();
      chrome.runtime.sendMessage({ action: "openOptionsPage" });
    },
    // 切换按钮显示/隐藏
    toggleVisibility() {
      const isButtonVisible = button.style.display !== "none";
      button.style.display = isButtonVisible ? "none" : "flex";
      if (isButtonVisible) {
        this.state.isPanelVisible = false;
        const isPanelOnLeft = this.state.currentPosition.x > window.innerWidth / 2;
        this.updatePanelPosition(isPanelOnLeft);
      }
    }
  };
  const createFloatingButton = () => {
    if (document.getElementById("pro-color-floating-button")) {
      return;
    }
    const container = document.createElement("div");
    container.id = "pro-color-container";
    container.classList.add("pro-color-protected");
    container.innerHTML = BUTTON_HTML;
    document.body.appendChild(container);
    const button2 = document.getElementById("pro-color-floating-button");
    const panel2 = document.getElementById("pro-color-theme-panel");
    button2.classList.add("pro-color-protected");
    panel2.classList.add("pro-color-protected");
    button2.style.backgroundColor = "#ffffff";
    panel2.style.backgroundColor = "white";
    document.querySelectorAll(".pro-color-theme-option").forEach((option) => {
      option.classList.add("pro-color-protected");
    });
    FloatingButtonController.init();
    window.__proColorButtonController = FloatingButtonController;
    return FloatingButtonController;
  };
  const toggleFloatingButton = () => {
    const buttonController = window.__proColorButtonController;
    if (buttonController) {
      buttonController.toggleVisibility();
    } else {
      const button2 = document.getElementById("pro-color-floating-button");
      if (button2) {
        const isVisible = button2.style.display !== "none";
        button2.style.display = isVisible ? "none" : "flex";
        if (isVisible) {
          const panel2 = document.getElementById("pro-color-theme-panel");
          if (panel2) {
            panel2.classList.remove("visible");
          }
        }
      }
    }
  };
  const main = () => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        initThemeHandler();
        createFloatingButton();
      });
    } else {
      initThemeHandler();
      createFloatingButton();
    }
  };
  main();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "applyTheme" && message.theme) {
      applyTheme(message.theme);
      sendResponse({ success: true });
    } else if (message.action === "toggleFloatingButton") {
      toggleFloatingButton();
      sendResponse({ success: true });
    }
    return true;
  });
})();
