const DEFAULT_THEMES = [
  { id: "theme-white", name: "白色主题", colorClass: "theme-white-color" },
  { id: "theme-green", name: "护眼绿色", colorClass: "theme-green-color" },
  { id: "theme-yellow", name: "黄色类纸", colorClass: "theme-yellow-color" },
  { id: "theme-night", name: "夜间深色", colorClass: "theme-night-color" }
];
const DEFAULT_CONFIG = {
  version: "1.0.0",
  themes: {},
  customThemes: {},
  floatingButtonPosition: {
    edge: "right",
    y: 50
  }
};
const STORAGE_KEY = "pro_color_config";
const getConfig = async () => {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return result[STORAGE_KEY] || DEFAULT_CONFIG;
  } catch (error) {
    console.error("Failed to get config:", error);
    return DEFAULT_CONFIG;
  }
};
const saveConfig = async (config) => {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: config });
  } catch (error) {
    console.error("Failed to save config:", error);
  }
};
const getSiteTheme = async (hostname) => {
  const config = await getConfig();
  return config.themes[hostname] || null;
};
const saveSiteTheme = async (hostname, theme) => {
  const config = await getConfig();
  config.themes[hostname] = theme;
  await saveConfig(config);
};
const saveButtonPosition = async (edge, y) => {
  const config = await getConfig();
  config.floatingButtonPosition = { edge, y };
  await saveConfig(config);
};
const exportConfig = async () => {
  const config = await getConfig();
  return JSON.stringify(config, null, 2);
};
const importConfig = async (jsonString) => {
  try {
    const config = JSON.parse(jsonString);
    if (!config.version || !config.themes) {
      throw new Error("Invalid config format");
    }
    await saveConfig(config);
    return true;
  } catch (error) {
    console.error("Failed to import config:", error);
    return false;
  }
};
const resetConfig = async () => {
  await saveConfig(DEFAULT_CONFIG);
};
export {
  DEFAULT_THEMES as D,
  getSiteTheme as a,
  saveSiteTheme as b,
  saveButtonPosition as c,
  exportConfig as e,
  getConfig as g,
  importConfig as i,
  resetConfig as r,
  saveConfig as s
};
